// Course data
const courseData = [
    {
        id: 1,
        title: "HTML Foundations",
        description: "Structure the web",
        icon: "fa-code",
        videoId: "qz0aGYrrlhU", // HTML Crash Course
        locked: false,
        completed: false,
        progress: 0,
        quiz: [
            {
                question: "What does HTML stand for?",
                options: [
                    "Hyper Text Markup Language",
                    "Home Tool Markup Language",
                    "Hyperlinks and Text Markup Language",
                    "Hyper Text Making Language"
                ],
                answer: 0
            },
            {
                question: "Which tag is used to create a hyperlink?",
                options: [
                    "<link>",
                    "<a>",
                    "<hl>",
                    "<hyperlink>"
                ],
                answer: 1
            },
            {
                question: "What is the correct HTML element for the largest heading?",
                options: [
                    "<h6>",
                    "<heading>",
                    "<h1>",
                    "<head>"
                ],
                answer: 2
            }
        ]
    },
    {
        id: 2,
        title: "CSS Styling",
        description: "Make it beautiful",
        icon: "fa-palette",
        videoId: "yfoY53QXEnI", // CSS Crash Course
        locked: true,
        completed: false,
        progress: 0,
        quiz: [
            {
                question: "What does CSS stand for?",
                options: [
                    "Computer Style Sheets",
                    "Creative Style Sheets",
                    "Cascading Style Sheets",
                    "Colorful Style Sheets"
                ],
                answer: 2
            },
            {
                question: "Which property is used to change the background color?",
                options: [
                    "bgcolor",
                    "color",
                    "background-color",
                    "bg-color"
                ],
                answer: 2
            },
            {
                question: "How do you select an element with id 'demo'?",
                options: [
                    ".demo",
                    "#demo",
                    "*demo",
                    "demo"
                ],
                answer: 1
            }
        ]
    },
    {
        id: 3,
        title: "Responsive Design",
        description: "Adapt to all screens",
        icon: "fa-mobile-alt",
        videoId: "srvUrASNj0s", // Responsive Design
        locked: true,
        completed: false,
        progress: 0,
        quiz: [
            {
                question: "What is the purpose of media queries in CSS?",
                options: [
                    "To apply styles based on device characteristics",
                    "To create animations",
                    "To define variables",
                    "To import other CSS files"
                ],
                answer: 0
            },
            {
                question: "Which viewport meta tag is essential for responsive design?",
                options: [
                    "<meta name='viewport' content='width=device-width, initial-scale=1.0'>",
                    "<meta name='responsive' content='true'>",
                    "<meta name='mobile' content='yes'>",
                    "<meta name='scale' content='1.0'>"
                ],
                answer: 0
            },
            {
                question: "Which CSS unit is most flexible for responsive layouts?",
                options: [
                    "px",
                    "em",
                    "rem",
                    "vw"
                ],
                answer: 3
            }
        ]
    },
    {
        id: 4,
        title: "JavaScript Basics",
        description: "Add interactivity",
        icon: "fa-code-branch",
        videoId: "W6NZfCO5SIk", // JavaScript Basics
        locked: true,
        completed: false,
        progress: 0,
        quiz: [
            {
                question: "Which of the following is NOT a JavaScript data type?",
                options: [
                    "Number",
                    "String",
                    "Boolean",
                    "Float"
                ],
                answer: 3
            },
            {
                question: "How do you declare a variable in JavaScript?",
                options: [
                    "variable x;",
                    "v x;",
                    "let x;",
                    "x = variable;"
                ],
                answer: 2
            },
            {
                question: "Which operator is used for strict equality comparison?",
                options: [
                    "==",
                    "===",
                    "=",
                    "!=="
                ],
                answer: 1
            }
        ]
    },
    {
        id: 5,
        title: "DOM Manipulation",
        description: "Control the page",
        icon: "fa-project-diagram",
        videoId: "0ik6X4DJKCc", // DOM Manipulation
        locked: true,
        completed: false,
        progress: 0,
        quiz: [
            {
                question: "What does DOM stand for?",
                options: [
                    "Document Object Model",
                    "Data Object Model",
                    "Display Object Management",
                    "Document Orientation Model"
                ],
                answer: 0
            },
            {
                question: "Which method selects the first element with a specific class?",
                options: [
                    "document.getElementById()",
                    "document.querySelector()",
                    "document.getElementsByClassName()[0]",
                    "document.findElement()"
                ],
                answer: 1
            },
            {
                question: "How do you change the text content of an element?",
                options: [
                    "element.text = 'new text'",
                    "element.innerHTML = 'new text'",
                    "element.textContent = 'new text'",
                    "element.value = 'new text'"
                ],
                answer: 2
            }
        ]
    },
    {
        id: 6,
        title: "APIs & Fetch",
        description: "Connect to data",
        icon: "fa-exchange-alt",
        videoId: "cuEtnrL9-H0", // Fetch API
        locked: true,
        completed: false,
        progress: 0,
        quiz: [
            {
                question: "What does API stand for?",
                options: [
                    "Application Programming Interface",
                    "Automated Programming Interface",
                    "Application Process Integration",
                    "Automated Process Integration"
                ],
                answer: 0
            },
            {
                question: "Which method is used to make a GET request with Fetch API?",
                options: [
                    "fetch.get()",
                    "fetch()",
                    "fetch.GET()",
                    "fetch.request()"
                ],
                answer: 1
            },
            {
                question: "What does the .json() method do on a fetch response?",
                options: [
                    "Converts the response to JSON",
                    "Validates the JSON",
                    "Sends JSON data",
                    "Parses the JSON"
                ],
                answer: 3
            }
        ]
    },
    {
        id: 7,
        title: "React Fundamentals",
        description: "Build modern UIs",
        icon: "fa-react",
        videoId: "w7ejDZ8SWv8", // React Basics
        locked: true,
        completed: false,
        progress: 0,
        quiz: [
            {
                question: "What is React?",
                options: [
                    "A programming language",
                    "A JavaScript library for building UIs",
                    "A database management system",
                    "A CSS framework"
                ],
                answer: 1
            },
            {
                question: "What is used to pass data to a component from outside?",
                options: [
                    "state",
                    "props",
                    "setState",
                    "render"
                ],
                answer: 1
            },
            {
                question: "Which hook is used for side effects in function components?",
                options: [
                    "useState",
                    "useEffect",
                    "useContext",
                    "useReducer"
                ],
                answer: 1
            }
        ]
    },
    {
        id: 8,
        title: "Backend Basics",
        description: "Node.js & Express",
        icon: "fa-server",
        videoId: "Oe421EPjeBE", // Node.js Basics
        locked: true,
        completed: false,
        progress: 0,
        quiz: [
            {
                question: "What is Node.js?",
                options: [
                    "A frontend JavaScript framework",
                    "A JavaScript runtime built on Chrome's V8 engine",
                    "A database system",
                    "A package manager"
                ],
                answer: 1
            },
            {
                question: "Which command initializes a new Node.js project?",
                options: [
                    "node init",
                    "npm start",
                    "npm init",
                    "node new"
                ],
                answer: 2
            },
            {
                question: "What is Express?",
                options: [
                    "A frontend framework",
                    "A database ORM",
                    "A web application framework for Node.js",
                    "A testing library"
                ],
                answer: 2
            }
        ]
    },
    {
        id: 9,
        title: "Databases",
        description: "Store your data",
        icon: "fa-database",
        videoId: "HXV3zeQKqGY", // SQL Basics
        locked: true,
        completed: false,
        progress: 0,
        quiz: [
            {
                question: "Which SQL statement retrieves data from a database?",
                options: [
                    "GET",
                    "SELECT",
                    "RETRIEVE",
                    "FIND"
                ],
                answer: 1
            },
            {
                question: "What is a primary key?",
                options: [
                    "A key that opens the database",
                    "A unique identifier for each record in a table",
                    "The first column in a table",
                    "A password for the database"
                ],
                answer: 1
            },
            {
                question: "Which NoSQL database uses JSON-like documents?",
                options: [
                    "MySQL",
                    "PostgreSQL",
                    "MongoDB",
                    "SQLite"
                ],
                answer: 2
            }
        ]
    },
    {
        id: 10,
        title: "Capstone Project",
        description: "Build a full app",
        icon: "fa-rocket",
        videoId: "GDa8kZLNhJ4", // Full Stack Project
        locked: true,
        completed: false,
        progress: 0,
        quiz: [
            {
                question: "What is the first step in planning a web application?",
                options: [
                    "Writing code",
                    "Choosing a color scheme",
                    "Defining requirements",
                    "Setting up the database"
                ],
                answer: 2
            },
            {
                question: "Which is NOT a common project structure?",
                options: [
                    "MVC (Model-View-Controller)",
                    "Client-Server",
                    "Monolithic",
                    "Single-File"
                ],
                answer: 3
            },
            {
                question: "What is version control important for?",
                options: [
                    "Tracking changes and collaborating",
                    "Making the app faster",
                    "Reducing server costs",
                    "Improving SEO"
                ],
                answer: 0
            }
        ]
    }
];

// DOM Elements
const levelsContainer = document.querySelector('.levels-container');
const levelModal = document.getElementById('levelModal');
const modalTitle = document.getElementById('modalTitle');
const levelVideo = document.getElementById('levelVideo');
const quizContainer = document.getElementById('quizContainer');
const quizQuestions = document.getElementById('quizQuestions');
const submitQuiz = document.getElementById('submitQuiz');
const quizResult = document.getElementById('quizResult');
const completionMessage = document.getElementById('completionMessage');
const nextLevelBtn = document.getElementById('nextLevel');
const closeModal = document.querySelector('.close-modal');
const startCourseBtn = document.getElementById('startCourse');
const progressCircle = document.querySelector('.progress-circle');
const userProgressText = document.querySelector('.user-progress span:last-child');

// Current level tracking
let currentLevel = null;
let userAnswers = [];

// Initialize the course
function initCourse() {
    renderLevels();
    
    // Event listeners
    closeModal.addEventListener('click', () => {
        levelModal.style.display = 'none';
    });
    
    window.addEventListener('click', (e) => {
        if (e.target === levelModal) {
            levelModal.style.display = 'none';
        }
    });
    
    submitQuiz.addEventListener('click', checkQuiz);
    nextLevelBtn.addEventListener('click', completeLevel);
    startCourseBtn.addEventListener('click', startCourse);
}

// Render all levels
function renderLevels() {
    levelsContainer.innerHTML = '';
    
    courseData.forEach(level => {
        const levelCard = document.createElement('div');
        levelCard.className = `level-card ${level.locked ? 'locked' : ''} ${level.completed ? 'completed' : ''}`;
        levelCard.dataset.id = level.id;
        
        levelCard.innerHTML = `
            <div class="level-header">
                <div class="level-icon tooltip">
                    <i class="fas ${level.icon}"></i>
                    <span class="tooltiptext">${level.title}</span>
                </div>
                <div class="level-info">
                    <h3>Level ${level.id}: ${level.title}</h3>
                    <p>${level.description}</p>
                </div>
            </div>
            <div class="level-content">
                <div class="progress-container">
                    <div class="progress-label">
                        <span>Progress</span>
                        <span>${level.progress}%</span>
                    </div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: ${level.progress}%"></div>
                    </div>
                </div>
                <div class="level-actions">
                    <button class="btn ${level.locked ? 'btn-primary' : 'btn-primary'}" ${level.locked ? 'disabled' : ''}>
                        <i class="fas ${level.locked ? 'fa-lock' : 'fa-play'}"></i> ${level.locked ? 'Locked' : 'Start'}
                    </button>
                </div>
            </div>
        `;
        
        if (!level.locked) {
            levelCard.addEventListener('click', () => openLevel(level.id));
        }
        
        levelsContainer.appendChild(levelCard);
    });
    
    updateOverallProgress();
}

// Open a level modal
function openLevel(levelId) {
    const level = courseData.find(l => l.id === levelId);
    if (!level) return;
    
    currentLevel = level;
    modalTitle.textContent = `Level ${level.id}: ${level.title}`;
    levelVideo.src = `https://www.youtube.com/embed/${level.videoId}?rel=0&enablejsapi=1`;
    
    // Render quiz questions
    quizQuestions.innerHTML = '';
    level.quiz.forEach((question, index) => {
        const questionDiv = document.createElement('div');
        questionDiv.className = 'quiz-question';
        questionDiv.innerHTML = `
            <p>${index + 1}. ${question.question}</p>
            ${question.options.map((option, i) => `
                <label class="quiz-option">
                    <input type="radio" name="q${index}" value="${i}">
                    ${option}
                </label>
            `).join('')}
        `;
        quizQuestions.appendChild(questionDiv);
    });
    
    // Reset quiz state
    userAnswers = [];
    quizResult.style.display = 'none';
    quizResult.innerHTML = '';
    completionMessage.style.display = 'none';
    
    // Show appropriate sections
    quizContainer.style.display = level.completed ? 'none' : 'block';
    
    levelModal.style.display = 'block';
}

// Check quiz answers
function checkQuiz() {
    const level = currentLevel;
    if (!level) return;
    
    // Get user answers
    userAnswers = [];
    let allAnswered = true;
    
    level.quiz.forEach((_, index) => {
        const selectedOption = document.querySelector(`input[name="q${index}"]:checked`);
        if (selectedOption) {
            userAnswers.push(parseInt(selectedOption.value));
        } else {
            allAnswered = false;
        }
    });
    
    if (!allAnswered) {
        quizResult.textContent = 'Please answer all questions before submitting.';
        quizResult.style.display = 'block';
        quizResult.style.backgroundColor = '#fff3cd';
        quizResult.style.color = '#856404';
        return;
    }
    
    // Calculate score
    let correct = 0;
    level.quiz.forEach((question, index) => {
        if (userAnswers[index] === question.answer) {
            correct++;
        }
    });
    
    const score = Math.round((correct / level.quiz.length) * 100);
    
    // Display result
    quizResult.innerHTML = `
        You scored ${score}% (${correct} out of ${level.quiz.length} correct)
        ${score >= 80 ? '🎉 Great job!' : 'Keep practicing!'}
    `;
    quizResult.style.display = 'block';
    quizResult.style.backgroundColor = score >= 80 ? '#d4edda' : '#f8d7da';
    quizResult.style.color = score >= 80 ? '#155724' : '#721c24';
    
    // Update level progress (80% video, 20% quiz)
    const videoProgress = 80; // Assuming user watched the full video
    const quizWeight = 0.2 * score;
    const newProgress = Math.min(100, videoProgress + quizWeight);
    
    level.progress = newProgress;
    
    // If progress reaches 100%, mark as completed
    if (newProgress >= 100) {
        level.completed = true;
        completionMessage.style.display = 'block';
        quizContainer.style.display = 'none';
        
        // Unlock next level if exists
        const nextLevel = courseData.find(l => l.id === level.id + 1);
        if (nextLevel) {
            nextLevel.locked = false;
        }
    }
    
    // Update UI
    updateOverallProgress();
    renderLevels();
}

// Complete the current level
function completeLevel() {
    levelModal.style.display = 'none';
}

// Update overall progress
function updateOverallProgress() {
    const completedLevels = courseData.filter(level => level.completed).length;
    const totalLevels = courseData.length;
    const overallProgress = Math.round((completedLevels / totalLevels) * 100);
    
    // Update progress circle
    progressCircle.style.background = `conic-gradient(var(--white) ${overallProgress}%, transparent 0%)`;
    progressCircle.querySelector('span').textContent = `${overallProgress}%`;
    
    // Update progress text
    userProgressText.textContent = `Level ${completedLevels} of ${totalLevels}`;
}

// Start the course (unlock first level)
function startCourse() {
    if (courseData[0].locked) {
        courseData[0].locked = false;
        renderLevels();
    }
    openLevel(1);
}

// Initialize the course when DOM is loaded
document.addEventListener('DOMContentLoaded', initCourse);